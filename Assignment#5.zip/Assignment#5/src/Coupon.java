//marker interface nothing to implement
public interface Coupon {

}
