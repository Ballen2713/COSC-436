//maker interface nothing implemented meant for JVM 
public interface SecondaryHeading {

}
