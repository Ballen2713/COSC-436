
public interface Receipt {
	void prtReceipt();
}
